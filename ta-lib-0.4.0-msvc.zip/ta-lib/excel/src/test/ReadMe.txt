These Excel files were used to do comparison
between an Excel implementation and the TA-Lib
implementation.

I found often useful to implement a TA function
first in Excel to get a sense of the algorithm
before doing the implementation in TA-Lib.

\Mario Fortier
